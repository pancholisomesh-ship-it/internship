// static/js/predict.js
document
  .getElementById("predict-form")
  .addEventListener("submit", async function (e) {
    e.preventDefault();
    const form = e.target;
    const features = [
      Number(form.channel.value),
      Number(form.region.value),
      Number(form.fresh.value),
      Number(form.milk.value),
      Number(form.grocery.value),
      Number(form.frozen.value),
      Number(form.detergents_paper.value),
      Number(form.delicassen.value),
    ];

    const resp = await fetch("/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ features }),
    });
    const data = await resp.json();
    if (resp.ok) {
      document.getElementById("result").innerText = "Cluster: " + data.cluster;
    } else {
      document.getElementById("result").innerText =
        "Error: " + (data.error || JSON.stringify(data));
    }
  });
